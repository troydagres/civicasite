import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        civica: {
          teal: '#006d77',
          navy: '#073b4c',
          green: '#39a96b',
          sky: '#8ecae6',
          mist: '#f6fbfb'
        }
      },
      boxShadow: {
        soft: '0 24px 80px rgba(7, 59, 76, 0.12)'
      }
    }
  },
  plugins: []
};

export default config;
