import { BarChart3, BookOpenCheck, CalendarDays, Cloud, Compass, Link2, ShieldCheck, Smartphone, UsersRound } from 'lucide-react';

export const navItems = [
  { label: 'Solution', href: '#solution' },
  { label: 'Discovery', href: '#discovery' },
  { label: 'Libraries', href: '#libraries' },
  { label: 'Resources', href: '#resources' },
  { label: 'Contact', href: '#contact' }
];

export const proofPoints = [
  '31M+ users worldwide',
  '2,000+ libraries',
  '40+ years working with library professionals'
];

export const featureCards = [
  {
    icon: Compass,
    title: 'Comprehensive discovery layer',
    text: 'Provide a public gateway to library resources with OPAC, BIBFRAME support, content databases, and a full discovery interface.'
  },
  {
    icon: Link2,
    title: 'Advanced integrations',
    text: 'Connect securely with eContent providers, payment services, discovery tools, identity systems, and library platforms through standards-based integrations.'
  },
  {
    icon: Smartphone,
    title: 'Full mobile stack',
    text: 'Support staff and patron engagement with mobile-first experiences designed for smooth operations and convenient self-service.'
  },
  {
    icon: CalendarDays,
    title: 'Strong engagement tools',
    text: 'Use events, reading challenges, marketing automation, and program visibility tools to increase community participation.'
  },
  {
    icon: UsersRound,
    title: 'Consortium ready',
    text: 'Scale across individual libraries, multi-branch systems, and consortia with shared infrastructure and local configuration flexibility.'
  },
  {
    icon: BarChart3,
    title: 'Business intelligence',
    text: 'Use built-in reporting, Staff Inquiry, and SpydusBI to demonstrate service impact and inform strategic decision-making.'
  }
];

export const benefits = [
  'Unified circulation, cataloging, acquisitions, patron management, discovery, events, and analytics.',
  'Configurable workflows that reduce repetitive administrative effort and support efficient service delivery.',
  'Cloud-native delivery that helps reduce local IT burden while keeping libraries current.',
  'Accessible, responsive user experiences for patrons and staff across devices.'
];

export const audienceCards = [
  {
    title: 'Public Libraries',
    text: 'Strengthen community engagement, simplify operations, and deliver modern patron experiences across every branch.',
    href: '#contact'
  },
  {
    title: 'Library Consortia',
    text: 'Unify shared services, discovery, reporting, and resource management while preserving local policy control.',
    href: '#contact'
  },
  {
    title: 'Special Libraries',
    text: 'Support highly configurable workflows for archival collections, cultural heritage, research, and specialist services.',
    href: '#contact'
  }
];

export const resourceCards = [
  {
    tag: 'Discovery',
    title: 'Create one gateway to library resources',
    text: 'Spydus helps patrons discover physical, digital, and community resources through a modern discovery experience.'
  },
  {
    tag: 'Operations',
    title: 'Replace vendor sprawl with one ILS ecosystem',
    text: 'A unified platform helps reduce complexity across core library operations, integrations, engagement, and analytics.'
  },
  {
    tag: 'Analytics',
    title: 'Demonstrate value with actionable insight',
    text: 'Spydus reporting and SpydusBI help libraries track usage, circulation, engagement, collection performance, and service impact.'
  }
];

export const platformPillars = [
  { icon: Cloud, label: 'Cloud-native SaaS' },
  { icon: ShieldCheck, label: 'Secure and resilient' },
  { icon: BookOpenCheck, label: 'Built for libraries' },
  { icon: BarChart3, label: 'Insight-driven' }
];
