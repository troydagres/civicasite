import { CheckCircle2 } from 'lucide-react';
import { benefits } from '@/lib/content';
import { ButtonLink } from './ButtonLink';

export function DiscoverySection() {
  return (
    <section id="discovery" className="mx-auto grid max-w-7xl gap-10 px-5 py-20 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
      <div>
        <p className="text-sm font-black uppercase tracking-[0.25em] text-civica-green">Discovery, operations, insight</p>
        <h2 className="mt-3 text-4xl font-black text-civica-navy md:text-5xl">Bring every part of the library journey together.</h2>
        <p className="mt-5 text-lg leading-8 text-slate-600">Spydus presents a unified experience for staff and patrons by connecting discovery, core operations, engagement, integrations, and reporting from a single platform.</p>
        <div className="mt-8 space-y-4">
          {benefits.map((item) => (
            <div key={item} className="flex gap-3">
              <CheckCircle2 className="mt-1 h-5 w-5 flex-none text-civica-green" />
              <p className="leading-7 text-slate-700">{item}</p>
            </div>
          ))}
        </div>
        <div className="mt-8"><ButtonLink href="#contact">Talk to Civica</ButtonLink></div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        {['Circulation', 'Cataloging', 'Acquisitions', 'Patron management', 'Discovery', 'Events', 'Reporting', 'SpydusBI'].map((item, index) => (
          <div key={item} className={`rounded-3xl p-6 shadow-sm ring-1 ring-slate-100 ${index % 3 === 0 ? 'bg-civica-navy text-white' : 'bg-white text-civica-navy'}`}>
            <span className={`mb-8 inline-flex h-10 w-10 items-center justify-center rounded-2xl text-sm font-black ${index % 3 === 0 ? 'bg-white/10' : 'bg-green-50 text-civica-green'}`}>{String(index + 1).padStart(2, '0')}</span>
            <h3 className="text-2xl font-black">{item}</h3>
            <p className={`mt-3 leading-7 ${index % 3 === 0 ? 'text-white/70' : 'text-slate-600'}`}>Part of the Spydus unified library ecosystem.</p>
          </div>
        ))}
      </div>
    </section>
  );
}
