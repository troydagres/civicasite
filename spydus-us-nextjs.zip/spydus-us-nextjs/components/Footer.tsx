import { LibraryBig } from 'lucide-react';
import Link from 'next/link';

export function Footer() {
  return (
    <footer className="bg-[#052f3c] px-5 py-10 text-white lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-civica-green"><LibraryBig className="h-5 w-5" /></div>
            <p className="text-xl font-black">Spydus by Civica</p>
          </div>
          <p className="mt-4 max-w-lg leading-7 text-white/65">Modern library technology for public libraries, consortia, academic libraries, and special libraries across the United States.</p>
        </div>
        <div>
          <p className="font-black">Explore</p>
          <div className="mt-4 space-y-2 text-white/65">
            <p><Link href="#solution">Solution</Link></p><p><Link href="#resources">Resources</Link></p><p><Link href="#libraries">Libraries</Link></p><p><Link href="#contact">Contact</Link></p>
          </div>
        </div>
        <div>
          <p className="font-black">Contact</p>
          <div className="mt-4 space-y-2 text-white/65">
            <p><Link href="mailto:libraries@civica.com">libraries@civica.com</Link></p><p>United States</p><p>Privacy Notice</p><p>Trust Center</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
