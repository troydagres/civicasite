import { audienceCards } from '@/lib/content';
import { ArrowRight } from 'lucide-react';
import Link from 'next/link';

export function AudienceSection() {
  return (
    <section id="libraries" className="bg-white py-20">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mb-10 max-w-3xl">
          <p className="text-sm font-black uppercase tracking-[0.25em] text-civica-green">Tailored solutions</p>
          <h2 className="mt-3 text-4xl font-black text-civica-navy md:text-5xl">Built for public libraries, consortia, and specialist services.</h2>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {audienceCards.map((card) => (
            <article key={card.title} className="rounded-3xl bg-civica-mist p-7 ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-soft">
              <h3 className="text-2xl font-black text-civica-navy">{card.title}</h3>
              <p className="mt-4 leading-7 text-slate-600">{card.text}</p>
              <Link className="focus-ring mt-6 inline-flex rounded-lg font-black text-civica-teal" href={card.href}>Learn more <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
