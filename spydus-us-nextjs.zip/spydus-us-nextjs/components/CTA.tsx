import { ButtonLink } from './ButtonLink';

export function CTA() {
  return (
    <section id="contact" className="bg-gradient-to-r from-civica-teal to-civica-navy py-16 text-white">
      <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 px-5 lg:flex-row lg:items-center lg:px-8">
        <div>
          <p className="text-sm font-black uppercase tracking-[0.25em] text-[#8de0c3]">Ready to learn more?</p>
          <h2 className="mt-3 text-4xl font-black">Request a Spydus demo for your library.</h2>
          <p className="mt-4 max-w-2xl text-lg leading-8 text-white/75">Tell us what you want to improve, and Civica can tailor the conversation around your workflows, integrations, reporting needs, and strategic priorities.</p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <ButtonLink href="mailto:libraries@civica.com" variant="light">Contact Us</ButtonLink>
          <ButtonLink href="#solution" variant="secondary">Explore Features</ButtonLink>
        </div>
      </div>
    </section>
  );
}
