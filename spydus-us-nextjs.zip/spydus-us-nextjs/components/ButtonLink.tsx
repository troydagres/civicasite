import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { ReactNode } from 'react';

export function ButtonLink({ href, children, variant = 'primary' }: { href: string; children: ReactNode; variant?: 'primary' | 'secondary' | 'light' }) {
  const styles = {
    primary: 'bg-civica-teal text-white hover:bg-[#035e66] shadow-lg shadow-civica-teal/20',
    secondary: 'border border-civica-green text-civica-green hover:bg-green-50',
    light: 'bg-white text-civica-teal hover:bg-slate-100 shadow-lg shadow-black/10'
  }[variant];

  return (
    <Link href={href} className={`focus-ring inline-flex items-center justify-center rounded-full px-6 py-3 text-sm font-bold transition ${styles}`}>
      {children}
      <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
    </Link>
  );
}
