import { CalendarDays, ChevronUp, Sparkles } from 'lucide-react';
import { ButtonLink } from './ButtonLink';
import { platformPillars, proofPoints } from '@/lib/content';

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[#ecfbf8] via-white to-[#eaf5ff]">
      <div className="absolute -left-24 top-20 h-72 w-72 rounded-full bg-[#9edecf]/40 blur-3xl" aria-hidden="true" />
      <div className="absolute -right-24 bottom-10 h-80 w-80 rounded-full bg-[#8ecae6]/30 blur-3xl" aria-hidden="true" />
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-[1fr_0.95fr] lg:px-8 lg:py-28">
        <div className="relative z-10">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#b8e4db] bg-white/80 px-4 py-2 text-sm font-bold text-civica-teal shadow-sm">
            <Sparkles className="h-4 w-4 fill-civica-green text-civica-green" /> Modern ILS for U.S. libraries
          </div>
          <h1 className="max-w-4xl text-5xl font-black leading-[1.02] tracking-tight text-civica-navy md:text-7xl">Keeping the library at the heart of your community.</h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-700 md:text-xl">Spydus is a complete, cloud-native integrated library system that supports individual libraries, multi-branch systems, and consortia. It unifies core library functions, streamlines operations, and empowers discovery of collections and services.</p>
          <div className="mt-9 flex flex-col gap-4 sm:flex-row">
            <ButtonLink href="#contact">Request a Demo</ButtonLink>
            <ButtonLink href="#resources" variant="secondary">Explore Spydus</ButtonLink>
          </div>
          <div className="mt-10 grid max-w-2xl gap-4 sm:grid-cols-3">
            {proofPoints.map((stat) => (
              <div key={stat} className="rounded-2xl bg-white/80 p-4 text-center shadow-sm ring-1 ring-slate-100">
                <p className="text-sm font-black text-civica-navy">{stat}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="relative z-10 rounded-[2rem] bg-white p-5 shadow-soft ring-1 ring-slate-100">
          <div className="rounded-[1.5rem] bg-civica-navy p-6 text-white">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70">Spydus platform view</p>
                <h2 className="text-2xl font-black">One ecosystem for library service</h2>
              </div>
              <div className="rounded-full bg-civica-green px-3 py-1 text-xs font-black">Unified</div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {platformPillars.map(({ icon: Icon, label }) => (
                <div key={label} className="rounded-2xl bg-white/10 p-5 backdrop-blur">
                  <Icon className="mb-4 h-7 w-7 text-[#8de0c3]" />
                  <p className="text-lg font-black">{label}</p>
                  <div className="mt-5 h-2 rounded-full bg-white/15"><div className="h-2 w-4/5 rounded-full bg-civica-green" /></div>
                </div>
              ))}
              <div className="rounded-2xl bg-white p-5 text-slate-900 md:col-span-2">
                <div className="flex items-center gap-3">
                  <CalendarDays className="h-5 w-5 text-civica-teal" />
                  <p className="font-black text-civica-navy">Engagement tools built in</p>
                </div>
                <div className="mt-4 grid gap-3 md:grid-cols-3">
                  {['Events', 'Reading challenges', 'Marketing automation'].map((item) => (
                    <div key={item} className="rounded-xl bg-[#f0fbf8] p-3 text-sm font-bold text-civica-navy">{item}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="absolute -bottom-5 -left-5 hidden rounded-2xl bg-white p-4 shadow-xl ring-1 ring-slate-100 md:block">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-50 text-civica-green"><ChevronUp className="h-6 w-6" /></span>
              <span><span className="block text-sm font-black text-civica-navy">Actionable insight</span><span className="block text-xs text-slate-500">Reporting, dashboards, SpydusBI</span></span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
