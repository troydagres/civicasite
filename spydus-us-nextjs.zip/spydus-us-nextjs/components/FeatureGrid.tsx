import { featureCards } from '@/lib/content';

export function FeatureGrid() {
  return (
    <section id="solution" className="bg-white py-20">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-black uppercase tracking-[0.25em] text-civica-green">Why Spydus</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight text-civica-navy md:text-5xl">A unified platform for the entire library experience.</h2>
          <p className="mt-5 text-lg leading-8 text-slate-600">Spydus combines the core ILS, discovery, mobile, engagement, integrations, and analytics capabilities libraries need to deliver modern service.</p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {featureCards.map(({ icon: Icon, title, text }) => (
            <article key={title} className="rounded-3xl bg-civica-mist p-7 shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-soft">
              <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-civica-teal text-white">
                <Icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-black text-civica-navy">{title}</h3>
              <p className="mt-3 leading-7 text-slate-600">{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
