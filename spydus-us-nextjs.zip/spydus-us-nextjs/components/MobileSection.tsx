import { ButtonLink } from './ButtonLink';

export function MobileSection() {
  return (
    <section className="bg-civica-navy py-20 text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-2 lg:px-8">
        <div>
          <p className="text-sm font-black uppercase tracking-[0.25em] text-[#8de0c3]">Full mobile stack</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Extend engagement beyond the branch.</h2>
          <p className="mt-5 text-lg leading-8 text-white/75">Spydus supports staff and patron mobile experiences so users can discover collections, manage accounts, register for events, and connect with library services wherever they are.</p>
          <div className="mt-8"><ButtonLink href="#contact" variant="light">Request mobile demo</ButtonLink></div>
        </div>
        <div className="rounded-[2rem] bg-white/10 p-6 ring-1 ring-white/15">
          <div className="mx-auto max-w-sm rounded-[2rem] bg-white p-4 text-slate-900 shadow-2xl">
            <div className="rounded-[1.5rem] bg-civica-mist p-5">
              <div className="mb-5 h-10 w-24 rounded-full bg-civica-navy" />
              <h3 className="text-2xl font-black text-civica-navy">My Library</h3>
              <p className="mt-2 text-sm text-slate-600">Your next visit starts here.</p>
              <div className="mt-6 space-y-3">
                {['Search the catalog', 'Renew items', 'Register for events', 'Manage your account'].map((item) => (
                  <div key={item} className="rounded-2xl bg-white p-4 font-bold text-civica-navy shadow-sm">{item}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
