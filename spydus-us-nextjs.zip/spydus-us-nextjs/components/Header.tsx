import Link from 'next/link';
import { LibraryBig, Menu } from 'lucide-react';
import { navItems } from '@/lib/content';
import { ButtonLink } from './ButtonLink';

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/70 bg-white/90 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <Link href="/" className="focus-ring flex items-center gap-3 rounded-2xl">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-civica-teal text-white shadow-lg shadow-teal-900/10">
            <LibraryBig className="h-6 w-6" />
          </span>
          <span>
            <span className="block text-xl font-extrabold tracking-tight text-civica-navy">Spydus</span>
            <span className="block text-xs font-bold uppercase tracking-[0.25em] text-civica-green">Civica Libraries</span>
          </span>
        </Link>
        <nav aria-label="Primary navigation" className="hidden items-center gap-8 text-sm font-bold text-slate-700 lg:flex">
          {navItems.map((item) => (
            <Link className="focus-ring rounded-lg transition hover:text-civica-teal" href={item.href} key={item.label}>{item.label}</Link>
          ))}
        </nav>
        <div className="hidden items-center gap-3 lg:flex">
          <Link className="focus-ring rounded-full border border-civica-teal px-5 py-3 text-sm font-bold text-civica-teal transition hover:bg-teal-50" href="#contact">Customer Login</Link>
          <ButtonLink href="#contact">Request a Demo</ButtonLink>
        </div>
        <button className="focus-ring rounded-xl p-2 lg:hidden" aria-label="Open menu"><Menu className="h-6 w-6" /></button>
      </div>
    </header>
  );
}
