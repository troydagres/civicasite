import { resourceCards } from '@/lib/content';
import { ArrowRight } from 'lucide-react';
import Link from 'next/link';

export function ResourcesSection() {
  return (
    <section id="resources" className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
      <div className="mb-8 flex items-end justify-between gap-6">
        <div>
          <p className="text-sm font-black uppercase tracking-[0.25em] text-civica-green">Spydus capabilities</p>
          <h2 className="mt-3 text-3xl font-black text-civica-navy md:text-4xl">Built around the needs of library leaders.</h2>
        </div>
        <Link className="focus-ring hidden rounded-lg font-black text-civica-teal md:inline-flex" href="#contact">View all resources <ArrowRight className="ml-2 h-5 w-5" /></Link>
      </div>
      <div className="grid gap-5 md:grid-cols-3">
        {resourceCards.map((item) => (
          <article key={item.title} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-soft">
            <p className="mb-4 inline-flex rounded-full bg-green-50 px-3 py-1 text-xs font-black uppercase tracking-wide text-civica-green">{item.tag}</p>
            <h3 className="text-xl font-black text-civica-navy">{item.title}</h3>
            <p className="mt-3 leading-7 text-slate-600">{item.text}</p>
            <Link className="focus-ring mt-5 inline-flex rounded-lg font-black text-civica-teal" href="#contact">Learn more <ArrowRight className="ml-2 h-4 w-4" /></Link>
          </article>
        ))}
      </div>
    </section>
  );
}
