import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Spydus ILS for U.S. Libraries | Civica Libraries',
  description: 'A production-style marketing site for Spydus, the cloud-native integrated library system for public libraries, consortia, academic libraries, and special libraries.',
  openGraph: {
    title: 'Spydus ILS for U.S. Libraries',
    description: 'Keeping the library at the heart of your community with a unified ILS for discovery, engagement, operations, and analytics.',
    type: 'website'
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en-US">
      <body>{children}</body>
    </html>
  );
}
