import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { ResourcesSection } from '@/components/ResourcesSection';
import { FeatureGrid } from '@/components/FeatureGrid';
import { DiscoverySection } from '@/components/DiscoverySection';
import { AudienceSection } from '@/components/AudienceSection';
import { MobileSection } from '@/components/MobileSection';
import { CTA } from '@/components/CTA';
import { Footer } from '@/components/Footer';

export default function HomePage() {
  return (
    <main>
      <Header />
      <Hero />
      <ResourcesSection />
      <FeatureGrid />
      <DiscoverySection />
      <AudienceSection />
      <MobileSection />
      <CTA />
      <Footer />
    </main>
  );
}
