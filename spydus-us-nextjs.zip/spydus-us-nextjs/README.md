# Spydus US Marketing Site

Production-style Next.js App Router marketing site for Spydus in the U.S. library market.

## Included

- Next.js App Router project structure
- Tailwind CSS theme with Civica-inspired colors
- Componentized homepage
- SEO metadata
- Responsive design
- Accessible focus states
- Vercel/Azure Static Web Apps-ready codebase

## Run locally

```bash
npm install
npm run dev
```

Open the local development URL shown in your terminal.

## Build

```bash
npm run build
npm start
```

## Content notes

The site uses Spydus positioning from internal collateral: unified ILS, discovery layer, advanced integrations, mobile stack, engagement tools, consortium readiness, reporting, Staff Inquiry, and SpydusBI. Replace placeholder contact links, legal links, and any unapproved customer proof points before external publication.
